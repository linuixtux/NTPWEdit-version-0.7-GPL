#ifndef __MESSAGE_H__
#define __MESSAGE_H__

INT_PTR AppMessageBox(HWND window, WCHAR *msg, UINT flags);

#endif /* __MESSAGE_H__ */
