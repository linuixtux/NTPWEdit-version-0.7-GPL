#ifndef __DLGPASS_H__
#define __DLGPASS_H__

INT_PTR QueryPassword(HWND window, char *pass, int pass_size);

#endif /* __DLGPASS_H__ */
