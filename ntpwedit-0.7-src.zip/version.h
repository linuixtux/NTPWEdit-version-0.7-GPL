#ifndef __VERSION_H__
#define __VERSION_H__

extern WCHAR const *AppTitle;
extern WCHAR const *AppAuthor;

#endif /* __VERSION_H__ */
