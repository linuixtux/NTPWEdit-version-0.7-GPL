extern struct DLG_Control CtlEdit;
extern struct DLG_Control CtlEditRight;
