extern struct DLG_Control CtlIcon;
extern struct DLG_Control CtlIcon16;
