extern struct DLG_Control CtlCheckBox;
extern struct DLG_Control CtlRadioBox;
extern struct DLG_Control CtlRadioBoxFirst;
