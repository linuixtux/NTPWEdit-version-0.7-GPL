extern struct DLG_Control CtlButton;
extern struct DLG_Control CtlDefButton;
extern struct DLG_Control CtlSmallButton;
