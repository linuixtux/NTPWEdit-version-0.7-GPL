extern struct DLG_Control CtlHotkey;
