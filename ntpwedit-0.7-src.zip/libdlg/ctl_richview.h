extern struct DLG_Control CtlRichView;
