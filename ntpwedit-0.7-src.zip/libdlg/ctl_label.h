extern struct DLG_Control CtlLabel;
extern struct DLG_Control CtlLabelCentered;
extern struct DLG_Control CtlLabelRight;
