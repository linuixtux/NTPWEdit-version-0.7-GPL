extern struct DLG_Control CtlListView;
