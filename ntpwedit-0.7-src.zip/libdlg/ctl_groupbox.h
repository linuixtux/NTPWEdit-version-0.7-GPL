extern struct DLG_Control CtlGroupBoxV;
extern struct DLG_Control CtlGroupBoxH;
extern struct DLG_Control CtlGroupBoxSpacer;
