#ifndef __DLGABOUT_H__
#define __DLGABOUT_H__

void AboutDialog(HWND window);

#endif /* __DLGABOUT_H__ */
