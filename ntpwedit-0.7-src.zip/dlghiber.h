#ifndef __DLGHIBER_H__
#define __DLGHIBER_H__

INT_PTR HiberWarning(HWND window);

#endif /* __DLGHIBER_H__ */
